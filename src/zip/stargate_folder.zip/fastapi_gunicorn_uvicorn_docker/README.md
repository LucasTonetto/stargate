# FastAPI + Gunicorn + Uvicorn + Docker

A FastAPI + Gunicorn + Uvicorn project using AsyncIO lib to produce messages to Kafka in concurrency using Docker
