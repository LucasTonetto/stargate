# Apache + Kafka + Zookeeper + Docker

A docker compose example to deploy multiple Kafka brokers, Zookeeper nodes and exporting monitoring jmx files in a VM cluster
