# FastAPI + Gunicorn + Uvicorn + Traefik + Docker

A FastAPI + Gunicorn + Uvicorn + Traefik project using AsyncIO lib to produce messages to Kafka in concurrency using Docker and via HTTPS using Traefik
